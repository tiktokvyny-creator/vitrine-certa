// @ts-nocheck
// Vitrine Certa · regras de avaliação de produtos — CÓPIA LITERAL do nó "Avaliar Produto"
// do workflow n8n admitad-sync-brl (exportado em 30/09/2026). Não editar à mão: qualquer
// ajuste de regra deve ser feito aqui e coberto por teste (evaluate.test.ts).
// Avaliar Produto — roda ANTES da IA. Faz, para cada item:
// 1) categorização determinística (idêntica à já validada em "Montar Produto Final");
// 2) avaliação de qualidade (rejeição obrigatória por regras fixas, incl. marcas de risco
//    e, quando a categoria é Moda, propriedade intelectual de terceiros — estampas de
//    personagens/bandas/lutadores/eventos não declarados como licenciados);
// 3) cálculo do score sintético de qualidade (0 a 6), usado só para ordenar na etapa de diversidade;
// 4) extração de shop_id de raw_payload.param, quando disponível.
// Produtos rejeitados nunca são enviados à IA (a IF "Rejeitado?" encerra o ramo aqui).
// Run Once for Each Item.

const ALLOWED_CATEGORIES = ['Eletrônicos','Casa','Moda','Beleza','Bebês e Brinquedos','Esporte','Livros','Outros'];

// ---- Normalização e correspondência por palavra/expressão (reaproveitado de Montar Produto Final) ----

function normalizeTitle(title) {
  return String(title || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function escapeRegExp(term) {
  return term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function matchesAny(normalizedTitle, terms) {
  return terms.some((term) => {
    const pattern = new RegExp(`\\b${escapeRegExp(term)}\\b`, 'i');
    return pattern.test(normalizedTitle);
  });
}

function findMatch(normalizedTitle, terms) {
  return terms.find((term) => {
    const pattern = new RegExp(`\\b${escapeRegExp(term)}\\b`, 'i');
    return pattern.test(normalizedTitle);
  }) || null;
}

// ---- Camada determinística de categorização (idêntica à de Montar Produto Final v3) ----

const DETERMINISTIC_RULES = [
  {
    category: 'Moda',
    terms: [
      'camiseta', 'camisa', 'regata', 'vestido', 'saia', 'calca', 'short', 'shorts',
      'bermuda', 'jaqueta', 'casaco', 'blusa', 'moletom', 'cueca', 'calcinha', 'sutia',
      'meia', 'meias', 'tenis', 'sapato', 'sapatos', 'sandalia', 'sandalias', 'bolsa',
      'mochila', 'bone', 'chapeu', 'cinto',
      'tank top', 'sleeveless shirt', 't-shirt', 'tshirt', 'shirt', 'dress', 'skirt',
      'pants', 'trousers', 'jacket', 'coat', 'blouse', 'hoodie', 'underwear', 'bra',
      'socks', 'sneakers', 'shoes', 'sandals', 'handbag', 'backpack', 'cap', 'hat',
      'belt', 'vest', 'jersey'
    ]
  },
  {
    category: 'Eletrônicos',
    terms: [
      'celular', 'celulares', 'computador', 'computadores', 'componente', 'componentes',
      'cabo', 'cabos', 'carregador', 'carregadores', 'fone', 'fones', 'caixa de som',
      'televisor', 'televisores', 'eletronico', 'eletronicos', 'smartwatch', 'smart watch',
      'usb-c', 'charger', 'cable', 'headphone', 'headphones', 'earphone', 'earphones',
      'earbud', 'earbuds', 'speaker', 'speakers', 'television', 'laptop', 'computer',
      'monitor', 'keyboard', 'mouse', 'printer', 'tablet', 'camera', 'router', 'adapter'
    ]
  },
  {
    category: 'Esporte',
    terms: [
      'halter', 'halteres', 'dumbbell', 'dumbbells', 'barbell', 'kettlebell',
      'equipamento de academia', 'equipamentos de academia', 'gym equipment',
      'bola esportiva', 'bolas esportivas', 'sports ball', 'esteira', 'treadmill',
      'bicicleta ergometrica', 'exercise bike', 'yoga mat', 'tapete de ioga'
    ]
  },
  {
    category: 'Livros',
    terms: ['livro', 'livros', 'ebook', 'e-book', 'book', 'books', 'revista', 'magazine']
  },
  {
    category: 'Bebês e Brinquedos',
    terms: [
      'brinquedo', 'brinquedos', 'bebe', 'bebes', 'baby', 'babies', 'toy', 'toys',
      'stroller', 'carrinho de bebe', 'crib', 'berco', 'pacifier', 'chupeta',
      'diaper', 'fralda', 'fraldas'
    ]
  },
  {
    category: 'Casa',
    terms: [
      'casa', 'cozinha', 'organizador', 'organizadores', 'organizer', 'kitchen',
      'decoracao', 'decoration', 'movel', 'moveis', 'furniture', 'storage',
      'organizacao'
    ]
  },
  {
    category: 'Beleza',
    terms: [
      'cosmetico', 'cosmeticos', 'maquiagem', 'perfume', 'perfumes',
      'cuidados pessoais', 'moisturizer', 'facial moisturizer', 'makeup',
      'cosmetic', 'skincare', 'face cream', 'creme facial', 'lipstick', 'batom', 'facial'
    ]
  }
];

function resolveDeterministicCategory(title) {
  const normalized = normalizeTitle(title);
  for (const rule of DETERMINISTIC_RULES) {
    if (matchesAny(normalized, rule.terms)) {
      return rule.category;
    }
  }
  return null;
}

// ---- Regras de rejeição obrigatória ----

const ADULT_TERMS = [
  'sex toy', 'sex toys', 'vibrator', 'vibrador', 'dildo', 'anal plug', 'butt plug',
  'plug anal', 'sex doll', 'boneca inflavel', 'inflatable doll', 'adult toy',
  'brinquedo erotico', 'brinquedo erótico', 'lingerie erotica', 'erotic lingerie'
];

const ILLEGAL_TERMS = [
  'weapon', 'weapons', 'gun', 'pistol', 'rifle', 'ammunition', 'ammo',
  'brass knuckles', 'knuckle duster', 'soqueira', 'taser',
  'arma', 'armas', 'arma de fogo', 'pistola', 'municao', 'munição',
  'drug', 'drugs', 'droga', 'drogas', 'cocaine', 'cocaina', 'cocaína', 'marijuana', 'maconha'
];

const PERSONALIZATION_TERMS = [
  'custom name', 'custom photo', 'personalized photo', 'personalized name',
  'add your name', 'add your photo', 'your photo here', 'your name here',
  'foto personalizada', 'nome personalizado', 'sua foto aqui', 'nome e foto'
];

// Marcas de rejeição direta (correspondência exata por palavra/expressão, sem exceção).
const RISK_BRANDS_HARD = [
  'nike', 'adidas', 'fila', 'puma', 'gucci', 'louis vuitton', 'chanel', 'dior', 'rolex'
];

// Apple/Samsung: podem aparecer em acessórios genéricos legítimos ("case for iPhone").
// "iphone" é tratado como termo da família Apple, pois é assim que o título normalmente
// menciona o produto (o feed raramente usa a palavra "Apple" literalmente).
const RISK_BRANDS_ACCESSORY_EXCEPTION = {
  Apple: ['apple', 'iphone'],
  Samsung: ['samsung']
};

const COMPATIBILITY_EXPRESSIONS = [
  'compatible with', 'compativel com', 'compatível com', 'for iphone', 'for samsung', 'para iphone', 'para samsung'
];

const ACCESSORY_TERMS = [
  'case', 'capa', 'cable', 'cabo', 'charger', 'carregador', 'screen protector',
  'pelicula', 'película', 'stand', 'suporte', 'band', 'pulseira', 'adapter', 'adaptador'
];

// Termos que, mesmo em contexto de acessório compatível, forçam rejeição por risco de
// falsificação/uso indevido da marca como se fosse produto oficial.
const BRAND_OVERRIDE_TERMS = [
  'original', 'official', 'oficial', 'genuine', 'autentico', 'autêntico', 'oem',
  'replica', 'réplica', 'fake', 'aaa quality', 'inspired by'
];

// Propriedade intelectual de terceiros (regra conservadora, aplicada SOMENTE quando a
// categoria determinística é Moda) — estampas/merchandising de personagens, bandas,
// lutadores, eventos, times, etc. que o feed não declara como licenciados.
// Termos específicos já confirmados em casos reais (execução 23: camisetas com nome de
// lutadora da WWE e com a marca do evento "Isle of Man TT").
const IP_RISK_GENERIC_TERMS = [
  // Português
  'estampado', 'estampa', 'logotipo', 'logo', 'personagem', 'anime', 'desenho animado',
  'filme', 'serie', 'cantor', 'cantora', 'banda', 'lutador', 'lutadora', 'luta livre',
  'evento', 'equipe', 'time', 'clube', 'corrida oficial', 'edicao comemorativa', 'inspirado em',
  // Inglês
  'printed', 'print', 'graphic', 'character', 'anime', 'cartoon', 'movie', 'series',
  'singer', 'rapper', 'band', 'wrestler', 'wrestling', 'celebrity', 'team', 'club',
  'official race', 'event', 'themed', 'inspired by', 'fan merchandise'
];

const IP_RISK_SPECIFIC_TERMS = [
  'rhea ripley', 'rhea rippley', 'rua rippley', 'isle of man tt', 'wwe', 'wwf',
  'loose rider', 'loose riders', 'loose rider global alliance', 'loose riders global alliance',
  'global alliance', 'lrga'
];

// Roupas esportivas de nicho (motocross/mtb/ciclismo) — regra conservadora adicional,
// aplicada quando a categoria determinística é Moda OU Esporte. Só rejeita quando o
// título combina um termo de nicho com um sinal de marca/equipe/réplica; roupa esportiva
// genérica (sem esses sinais) permanece elegível normalmente.
const SPORTSWEAR_IP_TRIGGER_TERMS = [
  'motocross', 'mtb', 'cycling jersey', 'racing jersey', 'motorcycle racing jersey'
];

const SPORTSWEAR_IP_SIGNAL_TERMS = [
  'official', 'logo', 'team', 'club', 'alliance', 'branded', 'replica', 'inspired by'
];

// Propriedade intelectual — jogo "ICO" (Sony Interactive Entertainment / Team Ico), o título
// correlato "Shadow of the Colossus" (mesmo estúdio) e a marca "PlayStation". Regra aplicada
// SOMENTE quando a categoria determinística é Moda, porque "ico" isoladamente pode ter outros
// significados fora do contexto de roupas (ex.: "ICO adapter" cai em Eletrônicos e não deve
// ser afetado por esta lista). matchesAny já aplica correspondência por palavra/expressão
// completa (\b...\b), então "ico" nunca combina como parte de outra palavra (ex.: "iconic").
const GAME_IP_RISK_TERMS_MODA_ONLY = [
  'ico', 'team ico', 'shadow of the colossus', 'playstation'
];

// Termos médicos/saúde regulada (português e inglês) — rejeição de prioridade máxima,
// independente da categoria bruta ou determinística. Inclui variantes sem acento porque
// normalizeTitle() remove diacríticos do título antes da comparação (mesmo padrão já usado
// em ADULT_TERMS/ILLEGAL_TERMS nesta base de código).
const MEDICAL_REGULATED_TERMS = [
  // Português
  'insulina', 'caneta de insulina', 'seringa', 'agulha',
  'cartucho de insulina', 'glicose', 'diabetes', 'diabético', 'diabetico',
  'lanceta', 'médico', 'medico', 'medicinal', 'pressão arterial', 'pressao arterial', 'inalador',
  // Inglês
  'insulin', 'insulin pen', 'injection pen', 'syringe', 'needle',
  'cartridge for injection', 'insulin cartridge', 'glucose', 'diabetic',
  'lancet', 'medical', 'pharma', 'pharmaceutical', 'blood pressure', 'inhaler'
];

// Termos reconhecidos de ferramenta/peça — usados apenas quando raw_payload.category é
// exatamente "Tool Parts" (política conservadora temporária: item sem termo reconhecido
// não segue para IA/Upsert).
const TOOL_PARTS_TERMS = [
  'tool', 'drill', 'wrench', 'screwdriver', 'plier', 'pliers', 'cutter', 'saw', 'grinder',
  'lathe', 'milling', 'pipe', 'tube', 'copper', 'expander', 'flaring',
  'welding', 'soldering', 'compressor', 'pneumatic', 'bearing',
  'motor', 'pump', 'valve', 'nozzle', 'adapter', 'fitting', 'bit'
];

function isTitleInvalid(rawTitle) {
  const trimmed = String(rawTitle || '').trim();
  if (trimmed.length < 3) return true;
  // "claramente corrompido": só caracteres não alfanuméricos (pontuação/símbolos repetidos)
  if (!/[a-zA-Z0-9À-ſ]/.test(trimmed)) return true;
  return false;
}

function evaluateBrandRisk(normalizedTitle) {
  const hardHit = findMatch(normalizedTitle, RISK_BRANDS_HARD);
  if (hardHit) {
    return { rejected: true, reason: 'marca_risco' };
  }

  for (const brand of Object.keys(RISK_BRANDS_ACCESSORY_EXCEPTION)) {
    const terms = RISK_BRANDS_ACCESSORY_EXCEPTION[brand];
    if (matchesAny(normalizedTitle, terms)) {
      // Marca da família Apple/Samsung detectada — verifica exceção de acessório.
      if (matchesAny(normalizedTitle, BRAND_OVERRIDE_TERMS)) {
        return { rejected: true, reason: 'marca_risco' };
      }
      const hasCompatExpression = matchesAny(normalizedTitle, COMPATIBILITY_EXPRESSIONS);
      const hasAccessoryTerm = matchesAny(normalizedTitle, ACCESSORY_TERMS);
      if (hasCompatExpression && hasAccessoryTerm) {
        return { rejected: false, reason: null };
      }
      return { rejected: true, reason: 'marca_risco' };
    }
  }

  return { rejected: false, reason: null };
}

// ---- Score de qualidade sintético (0 a 6) — só para ordenação, não é medida real de reputação ----

function hasExcessiveRepetition(normalizedTitle) {
  const words = normalizedTitle.split(' ').filter((w) => w.length >= 3);
  if (words.length < 4) return false;
  const counts = {};
  for (const w of words) counts[w] = (counts[w] || 0) + 1;
  const maxCount = Math.max(...Object.values(counts));
  const uniqueRatio = new Set(words).size / words.length;
  return maxCount > 3 || uniqueRatio < 0.5;
}

function computeQualityScore({ hasDeterministicCategory, discountPercent, rawTitle, normalizedTitle, shopId }) {
  let score = 0;

  if (hasDeterministicCategory) {
    score += 2;
  }

  if (discountPercent !== null && discountPercent !== undefined) {
    if (discountPercent >= 10 && discountPercent <= 50) {
      score += 2;
    } else if (discountPercent > 50 && discountPercent <= 65) {
      score += 1;
    }
    // > 65 e <= 80: +0 (nenhum ponto, mas não é motivo de rejeição)
  }

  const trimmedLen = String(rawTitle || '').trim().length;
  if (trimmedLen >= 15 && trimmedLen <= 160 && !hasExcessiveRepetition(normalizedTitle)) {
    score += 1;
  }

  if (shopId) {
    score += 1;
  }

  return score;
}

// ---- Extração de shop_id do param (formato "chave|valor|;chave|valor|;...") ----

function extractShopId(paramStr) {
  if (!paramStr || typeof paramStr !== 'string') return null;
  const parts = paramStr.split(';').filter(Boolean);
  for (const part of parts) {
    const segments = part.split('|');
    const key = (segments[0] || '').trim();
    const value = (segments[1] || '').trim();
    if (key === 'shopId' && value) {
      return value;
    }
  }
  return null;
}

// ---- Avaliação principal ----

function evaluateProduct(item, categoryCandidate) {
  const rawTitle = item.title;
  const normalizedTitle = normalizeTitle(rawTitle);

  // 0. Saúde regulada — prioridade máxima: roda antes de qualquer outra regra (incl.
  // título/preço/Tool Parts) e independentemente da categoria bruta ou determinística.
  if (matchesAny(normalizedTitle, MEDICAL_REGULATED_TERMS)) {
    return { rejected: true, reason: 'saude_regulada' };
  }

  // 1. Título vazio/corrompido
  if (isTitleInvalid(rawTitle)) {
    return { rejected: true, reason: 'titulo_invalido' };
  }

  // 2. Preços inválidos (não numéricos, <=0, ou sem desconto real)
  const price = Number(item.price);
  const oldPrice = Number(item.old_price);
  if (!Number.isFinite(price) || !Number.isFinite(oldPrice)) {
    return { rejected: true, reason: 'preco_invalido' };
  }
  if (price <= 0) {
    return { rejected: true, reason: 'preco_invalido' };
  }
  if (oldPrice <= price) {
    return { rejected: true, reason: 'preco_invalido' };
  }

  const discountPercent = item.discount_percent !== null && item.discount_percent !== undefined
    ? Number(item.discount_percent)
    : Math.round(((oldPrice - price) / oldPrice) * 10000) / 100;

  // 3/4. Faixa de desconto
  if (discountPercent < 10) {
    return { rejected: true, reason: 'desconto_baixo' };
  }
  if (discountPercent > 80) {
    return { rejected: true, reason: 'desconto_alto' };
  }

  // 5. HTTPS obrigatório
  const imageUrl = String(item.image_url || '');
  const affiliateUrl = String(item.affiliate_url || '');
  if (!imageUrl.startsWith('https://') || !affiliateUrl.startsWith('https://')) {
    return { rejected: true, reason: 'sem_https' };
  }

  // 6. Conteúdo adulto / itens ilegais ou perigosos
  if (matchesAny(normalizedTitle, ADULT_TERMS) || matchesAny(normalizedTitle, ILLEGAL_TERMS)) {
    return { rejected: true, reason: 'conteudo_proibido' };
  }

  // 7. Marca de risco (com exceção de acessório Apple/Samsung)
  const brandRisk = evaluateBrandRisk(normalizedTitle);
  if (brandRisk.rejected) {
    return { rejected: true, reason: 'marca_risco' };
  }

  // 8. Produto personalizado (nome/foto do comprador)
  if (matchesAny(normalizedTitle, PERSONALIZATION_TERMS)) {
    return { rejected: true, reason: 'personalizado' };
  }

  // 9. Propriedade intelectual de terceiros — regra conservadora, só quando a categoria
  // determinística é Moda (roupa lisa/básica sem estampa continua elegível normalmente).
  if (categoryCandidate === 'Moda') {
    if (matchesAny(normalizedTitle, IP_RISK_SPECIFIC_TERMS) || matchesAny(normalizedTitle, IP_RISK_GENERIC_TERMS)) {
      return { rejected: true, reason: 'propriedade_intelectual_risco' };
    }
  }

  // 9b. Roupas esportivas de nicho (motocross/mtb/ciclismo) com sinal de marca/equipe —
  // regra conservadora adicional, aplicada quando a categoria é Moda ou Esporte. Não
  // rejeita roupa esportiva genérica sem esses sinais.
  if (categoryCandidate === 'Moda' || categoryCandidate === 'Esporte') {
    if (matchesAny(normalizedTitle, SPORTSWEAR_IP_TRIGGER_TERMS) && matchesAny(normalizedTitle, SPORTSWEAR_IP_SIGNAL_TERMS)) {
      return { rejected: true, reason: 'propriedade_intelectual_risco' };
    }
  }

  // 9c. Propriedade intelectual — jogo ICO / Shadow of the Colossus / PlayStation — regra
  // conservadora adicional, aplicada apenas quando a categoria determinística é Moda (ver
  // comentário de GAME_IP_RISK_TERMS_MODA_ONLY acima sobre por que o escopo é restrito).
  if (categoryCandidate === 'Moda') {
    if (matchesAny(normalizedTitle, GAME_IP_RISK_TERMS_MODA_ONLY)) {
      return { rejected: true, reason: 'propriedade_intelectual_risco' };
    }
  }

  // 10. Tool Parts (raw_payload.category) — política conservadora temporária: sem termo
  // reconhecido de ferramenta/peça, o item não segue para IA/Upsert. A regra saude_regulada
  // (passo 0) sempre roda antes e tem prioridade sobre esta categorização.
  const rawCategory = String(item.raw_payload?.category ?? '').trim().toLowerCase();
  let resolvedCategory = categoryCandidate;
  if (rawCategory === 'tool parts') {
    if (matchesAny(normalizedTitle, TOOL_PARTS_TERMS)) {
      resolvedCategory = 'Casa';
    } else {
      return { rejected: true, reason: 'tool_parts_nao_classificado' };
    }
  }

  return { rejected: false, reason: null, discountPercent, resolvedCategory };
}


// ---- Exportações (equivalente à seção "Execução" do nó original) ----
export function evaluate(item) {
  const rawTitle = item.title;
  const normalizedTitle = normalizeTitle(rawTitle);
  const categoryCandidate = resolveDeterministicCategory(rawTitle);
  const evaluation = evaluateProduct(item, categoryCandidate);
  const shopId = extractShopId(item.raw_payload && item.raw_payload.param);
  const deterministicCategory = evaluation.rejected ? null : evaluation.resolvedCategory;
  let qualityScore = 0;
  if (!evaluation.rejected) {
    qualityScore = computeQualityScore({
      hasDeterministicCategory: Boolean(deterministicCategory),
      discountPercent: evaluation.discountPercent,
      rawTitle, normalizedTitle, shopId,
    });
  }
  return { ...item, category: deterministicCategory, shop_id: shopId,
    quality: { rejected: evaluation.rejected, reason: evaluation.reason, score: qualityScore } };
}
export { ALLOWED_CATEGORIES, normalizeTitle, resolveDeterministicCategory, evaluateProduct, extractShopId };
