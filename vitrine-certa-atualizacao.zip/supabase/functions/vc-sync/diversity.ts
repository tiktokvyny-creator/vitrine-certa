// @ts-nocheck
// Vitrine Certa · seleção por diversidade — CÓPIA LITERAL do nó "Selecionar Diversidade"
// do workflow n8n admitad-sync-brl (exportado em 30/09/2026): máx. 5 produtos, 2 por categoria,
// 1 por loja, sem títulos ou imagens duplicados; ordena por score, desconto e external_id.
function normalizeTitle(title) {
  return String(title || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function selectDiverse(approved) {
  const sorted = [...approved].sort((a, b) => {
    const scoreA = (a.quality && a.quality.score) || 0;
    const scoreB = (b.quality && b.quality.score) || 0;
    if (scoreB !== scoreA) return scoreB - scoreA;

    const discA = a.discount_percent === null || a.discount_percent === undefined ? 0 : a.discount_percent;
    const discB = b.discount_percent === null || b.discount_percent === undefined ? 0 : b.discount_percent;
    if (discB !== discA) return discB - discA;

    return String(a.external_id).localeCompare(String(b.external_id));
  });

  const selected = [];
  const seenTitles = new Set();
  const seenImages = new Set();
  const categoryCount = {};
  const shopCount = {};
  const descartadosPorDiversidade = {
    duplicado_titulo: 0,
    duplicado_imagem: 0,
    limite_categoria: 0,
    limite_loja: 0
  };

  for (const p of sorted) {
    if (selected.length >= 5) break;

    const titleKey = normalizeTitle(p.title);
    const imageKey = String(p.image_url || '').trim();
    const category = p.category || 'Outros';
    const shopId = p.shop_id;

    if (titleKey && seenTitles.has(titleKey)) {
      descartadosPorDiversidade.duplicado_titulo++;
      continue;
    }
    if (imageKey && seenImages.has(imageKey)) {
      descartadosPorDiversidade.duplicado_imagem++;
      continue;
    }
    if ((categoryCount[category] || 0) >= 2) {
      descartadosPorDiversidade.limite_categoria++;
      continue;
    }
    if (shopId && (shopCount[shopId] || 0) >= 1) {
      descartadosPorDiversidade.limite_loja++;
      continue;
    }

    selected.push(p);
    if (titleKey) seenTitles.add(titleKey);
    if (imageKey) seenImages.add(imageKey);
    categoryCount[category] = (categoryCount[category] || 0) + 1;
    if (shopId) shopCount[shopId] = (shopCount[shopId] || 0) + 1;
  }

  return { selected, descartadosPorDiversidade };
}


export { selectDiverse };
