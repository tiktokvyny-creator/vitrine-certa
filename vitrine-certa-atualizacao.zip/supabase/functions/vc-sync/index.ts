// Vitrine Certa · Edge Function "vc-sync" — busca de novas ofertas (substitui o n8n admitad-sync-brl).
// Chamada pelo banco (vc_start_sync → pg_net) com x-vc-job-secret, ou com a service role.
// Usa: admitad-feed-sampler (mesmo projeto, header INTERNAL_TRIGGER_SECRET), OpenAI (OPENAI_API_KEY,
// opcional: sem chave, itens sem categoria determinística ficam em "Outros").
// Nunca registra URLs, chaves, títulos ou raw_payload.
import { createClient } from "npm:@supabase/supabase-js@2.117.1";
import { AI_PROMPT, runSync, type SampledProduct } from "./pipeline.ts";

const URL_BASE = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const service = createClient(URL_BASE, SERVICE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });
const log = (stage: string, data: Record<string, unknown> = {}) =>
  service.rpc("vc_feed_scan_log", { p_stage: stage, p_data: data }).then(() => {}, () => {});
const UUID = /^[0-9a-f-]{36}$/i;

function safeEq(a: string, b: string) {
  if (a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0;
}
async function authorized(req: Request) {
  const auth = req.headers.get("authorization") ?? "";
  if (auth.startsWith("Bearer ") && SERVICE_KEY && safeEq(auth.slice(7).trim(), SERVICE_KEY)) return true;
  const s = req.headers.get("x-vc-job-secret") ?? "";
  if (!s) return false;
  const { data } = await service.rpc("vc_job_secret_ok", { p_name: "vc_jobs", p_value: s });
  return data === true;
}
async function withTimeout<T>(ms: number, fn: (signal: AbortSignal) => Promise<T>): Promise<T> {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
  try { return await fn(c.signal); } finally { clearTimeout(t); }
}

async function fetchSample(): Promise<SampledProduct[]> {
  const secret = Deno.env.get("INTERNAL_TRIGGER_SECRET") ?? "";
  if (!secret) throw Object.assign(new Error("no_sampler_secret"), { code: "sampler_error" });
  const res = await withTimeout(60_000, (signal) => fetch(`${URL_BASE}/functions/v1/admitad-feed-sampler`, {
    method: "POST", signal, headers: { "Content-Type": "application/json", "x-internal-trigger-secret": secret },
    body: JSON.stringify({ limit: 20 }),
  }));
  const body = await res.json().catch(() => null) as { ok?: boolean; products?: SampledProduct[] } | null;
  if (!res.ok || !body || body.ok !== true || !Array.isArray(body.products)) throw Object.assign(new Error("sampler"), { code: "sampler_error" });
  return body.products;
}

const OPENAI_KEY = Deno.env.get("OPENAI_API_KEY") ?? "";
async function classify(title: string): Promise<string> {
  if (!OPENAI_KEY) throw new Error("ai_unavailable");
  const res = await withTimeout(15_000, (signal) => fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST", signal,
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${OPENAI_KEY}` },
    body: JSON.stringify({ model: "gpt-4o-mini", temperature: 0, max_tokens: 12,
      messages: [{ role: "user", content: AI_PROMPT(title) }] }),
  }));
  if (!res.ok) { await res.body?.cancel().catch(() => {}); throw new Error("ai_http"); }
  const j = await res.json();
  return String(j?.choices?.[0]?.message?.content ?? "");
}

async function upsert(rows: Record<string, unknown>[]): Promise<number> {
  const { data, error } = await service.from("affiliate_products")
    .upsert(rows, { onConflict: "network,external_id" }).select("id");
  if (error) throw Object.assign(new Error("upsert"), { code: "upsert_error" });
  return Array.isArray(data) ? data.length : 0;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: false }, 405);
  if (!(await authorized(req))) return json({ ok: false, code: "unauthorized" }, 401);
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { return json({ ok: false, code: "bad_request" }, 400); }
  const runId = typeof b.run_id === "string" && UUID.test(b.run_id) ? b.run_id : "";
  if (!runId) return json({ ok: false, code: "bad_request" }, 400);

  const { data: run } = await service.from("admin_job_runs").select("id, kind, status").eq("id", runId).maybeSingle();
  if (!run || run.kind !== "sync" || run.status !== "requested") return json({ ok: false, code: "bad_run" }, 409);
  await service.from("admin_job_runs").update({ status: "running", started_at: new Date().toISOString() }).eq("id", runId);
  const finish = (patch: Record<string, unknown>) =>
    service.from("admin_job_runs").update({ finished_at: new Date().toISOString(), ...patch }).eq("id", runId);
  const t0 = Date.now();
  try {
    const r = await runSync({
      fetchSample, classify, upsert, now: () => new Date(),
      log: (_e, d) => { void log("sync_summary", { run_id: runId, ...(d ?? {}), ai_key: OPENAI_KEY ? "present" : "missing" }); },
    });
    await finish({ status: "completed", found: r.found, rejected: r.rejected, approved: r.approved, saved: r.saved, error_code: null });
    return json({ ok: true, run_id: runId, ms: Date.now() - t0, found: r.found, rejected: r.rejected, approved: r.approved, saved: r.saved });
  } catch (e) {
    const code = (e as { code?: string })?.code ?? "sync_error";
    await finish({ status: "failed", error_code: code });
    await log("sync_failed", { run_id: runId, code });
    return json({ ok: false, code }, 502);
  }
});
