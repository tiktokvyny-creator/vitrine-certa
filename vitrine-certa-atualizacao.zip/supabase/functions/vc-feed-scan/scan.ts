// Vitrine Certa · leitura rápida do feed Admitad (CSV ";" em streaming).
// Só examina a fundo as linhas cujo id interessa; para todas as outras lê apenas o 1º campo.
// Valores de price/oldprice já são BRL efetivo (currencyId do feed diz "USD", mas é só rótulo —
// auditado em 17/09/2026). Nunca converte câmbio.

export interface Evidence { price: number; old_price: number | null; row: number }
export interface ScanResult {
  found: Map<string, Evidence>;
  rows: number;
  reason: "allFound" | "deadline" | "endOfFeed";
}

/** Separa UMA linha CSV respeitando aspas ("" = aspas literal). */
export function splitCsvLine(line: string, delim = ";"): string[] {
  const out: string[] = [];
  let field = "", q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"') { if (line[i + 1] === '"') { field += '"'; i++; } else q = false; }
      else field += c;
    } else if (c === '"' && field === "") q = true;
    else if (c === delim) { out.push(field); field = ""; }
    else if (c !== "\r") field += c;
  }
  out.push(field);
  return out;
}

const num = (s: string | undefined) => {
  if (s === undefined || s.trim() === "") return null;
  const n = Number(s.trim().replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

/** Evidência válida só com preço > 0 e < 10 milhões; old_price só se maior que o preço. */
export function toEvidence(price: number | null, old: number | null, row: number): Evidence | null {
  if (price === null || !(price > 0) || price >= 10_000_000) return null;
  const p = Math.round(price * 100) / 100;
  const o = old !== null && old > p && old < 10_000_000 ? Math.round(old * 100) / 100 : null;
  return { price: p, old_price: o, row };
}

export async function scanFeed(
  body: ReadableStream<Uint8Array>,
  want: Set<string>,
  opts: { deadlineAt: number; now?: () => number; onProgress?: (rows: number, found: number) => void; progressEvery?: number },
): Promise<ScanResult> {
  const now = opts.now ?? Date.now;
  const every = opts.progressEvery ?? 20000;
  const found = new Map<string, Evidence>();
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "", header: string[] | null = null, rows = 0, next = every;
  let iId = -1, iPrice = -1, iOld = -1;
  let reason: ScanResult["reason"] = "endOfFeed";
  const handle = (line: string): boolean => {
    if (!header) {
      header = splitCsvLine(line.replace(/^\uFEFF/, "")).map((h) => h.trim().toLowerCase());
      iId = header.indexOf("id"); iPrice = header.indexOf("price");
      iOld = header.indexOf("oldprice") >= 0 ? header.indexOf("oldprice") : header.indexOf("old_price");
      if (iId < 0 || iPrice < 0) throw new Error("invalid_feed_header");
      return false;
    }
    rows++;
    // Caminho rápido: extrai só o campo do id (é a 1ª coluna no feed atual).
    let id: string | undefined;
    if (iId === 0) {
      const cut = line.indexOf(";");
      id = (cut < 0 ? line : line.slice(0, cut)).replace(/^"|"$/g, "").trim();
    } else id = splitCsvLine(line)[iId]?.trim();
    if (!id || !want.has(id) || found.has(id)) return false;
    const cols = splitCsvLine(line);
    const ev = toEvidence(num(cols[iPrice]), iOld >= 0 ? num(cols[iOld]) : null, rows);
    if (ev) found.set(id, ev);
    return found.size === want.size;
  };
  try {
    outer: while (true) {
      const { done, value } = await reader.read();
      if (done) { buf += dec.decode(); if (buf.trim()) handle(buf); break; }
      buf += dec.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.trim()) continue;
        if (handle(line)) { reason = "allFound"; break outer; }
      }
      if (rows >= next) { next += every; opts.onProgress?.(rows, found.size); }
      if (now() > opts.deadlineAt) { reason = "deadline"; break; }
    }
  } finally {
    await reader.cancel().catch(() => {});
  }
  return { found, rows, reason };
}

export const discountOf = (price: number, old: number | null) =>
  old !== null && old > price ? Math.round((1 - price / old) * 100) : null;
