// Vitrine Certa · Edge Function "vc-feed-scan" — verificação de preços no feed Admitad.
// Modos:
//   check_all {run_id}      → confere TODAS as ofertas com external_id (chamado pelo pg_cron
//                             ou pelo painel via vc_start_price_scan). Grava preço confirmado,
//                             marca não confirmados e pausa ativas com 2+ falhas seguidas.
//   check_one {run_id, external_id} → devolve a evidência de UMA oferta para a vc-admin-jobs
//                             (contrato: run_id, external_id, found, price, old_price, currency, source, observed_at).
// Autenticação: header x-vc-job-secret (agendador) OU Authorization: Bearer <service role> (vc-admin-jobs).
// Nunca registra a URL do feed, segredos ou títulos.
import { createClient } from "npm:@supabase/supabase-js@2.117.1";
import { discountOf, scanFeed } from "./scan.ts";

const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const service = createClient(Deno.env.get("SUPABASE_URL")!, SERVICE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "Content-Type": "application/json" } });
const log = (stage: string, data: Record<string, unknown>) =>
  service.rpc("vc_feed_scan_log", { p_stage: stage, p_data: data }).then(() => {}, () => {});
const UUID = /^[0-9a-f-]{36}$/i;
const EXT = /^[A-Za-z0-9._:-]{1,64}$/;

function safeEq(a: string, b: string) {
  if (a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0;
}
async function authorized(req: Request) {
  const auth = req.headers.get("authorization") ?? "";
  if (auth.startsWith("Bearer ") && SERVICE_KEY && safeEq(auth.slice(7).trim(), SERVICE_KEY)) return true;
  const s = req.headers.get("x-vc-job-secret") ?? "";
  if (!s) return false;
  const { data } = await service.rpc("vc_job_secret_ok", { p_name: "vc_jobs", p_value: s });
  return data === true;
}

async function openFeed(signal: AbortSignal) {
  const url = Deno.env.get("ADMITAD_FEED_URL");
  if (!url) throw Object.assign(new Error("not_configured"), { code: "not_configured" });
  const res = await fetch(url, { signal });
  if (!res.ok || !res.body) throw Object.assign(new Error("upstream"), { code: "n8n_error" });
  return res.body;
}

async function checkAll(runId: string) {
  const t0 = Date.now();
  const { data: run } = await service.from("admin_job_runs").select("id, kind, status, product_id").eq("id", runId).maybeSingle();
  if (!run || run.kind !== "price_check" || run.product_id !== null || run.status !== "requested") return json({ ok: false, code: "bad_run" }, 409);
  await service.from("admin_job_runs").update({ status: "running", started_at: new Date().toISOString() }).eq("id", runId);
  const finish = (patch: Record<string, unknown>) =>
    service.from("admin_job_runs").update({ finished_at: new Date().toISOString(), ...patch }).eq("id", runId);
  try {
    const { data: prods, error } = await service.from("affiliate_products")
      .select("id, external_id, active, price, price_check_misses")
      .not("external_id", "is", null).eq("network", "admitad_aliexpress");
    if (error) throw error;
    const byExt = new Map<string, { id: string; active: boolean; price: number | null; misses: number }>();
    for (const p of prods ?? []) byExt.set(String(p.external_id), { id: p.id, active: p.active, price: p.price === null ? null : Number(p.price), misses: p.price_check_misses ?? 0 });
    const ctrl = new AbortController();
    const body = await openFeed(ctrl.signal);
    const r = await scanFeed(body, new Set(byExt.keys()), {
      deadlineAt: t0 + 130_000,
      onProgress: (rows, found) => { void log("check_all_progress", { run_id: runId, rows, found }); },
    });
    ctrl.abort();
    const now = new Date().toISOString();
    let confirmed = 0, changed = 0, unconfirmed = 0;
    const missIds: string[] = [];
    for (const [ext, p] of byExt) {
      const ev = r.found.get(ext);
      if (ev) {
        confirmed++;
        if (p.price === null || Math.abs(p.price - ev.price) >= 0.005) changed++;
        const { error: e } = await service.from("affiliate_products").update({
          price: ev.price, old_price: ev.old_price, discount_percent: discountOf(ev.price, ev.old_price),
          source_price: ev.price, source_old_price: ev.old_price,
          price_checked_at: now, price_check_status: "confirmed", price_check_misses: 0, last_synced_at: now,
        }).eq("id", p.id);
        if (e) throw e;
      } else {
        unconfirmed++;
        const { error: e } = await service.from("affiliate_products").update({
          price_checked_at: now, price_check_status: "unconfirmed", price_check_misses: p.misses + 1,
        }).eq("id", p.id);
        if (e) throw e;
        if (p.active && p.misses + 1 >= 2) missIds.push(p.id);
      }
    }
    let paused = 0;
    if (missIds.length) {
      const { data: n, error: e } = await service.rpc("vc_auto_pause", { p_ids: missIds });
      if (e) throw e;
      paused = Number(n) || 0;
    }
    await finish({ status: "completed", found: confirmed, rejected: unconfirmed, approved: changed, saved: paused, error_code: null });
    const summary = { run_id: runId, rows: r.rows, reason: r.reason, ms: Date.now() - t0, confirmed, changed, unconfirmed, paused };
    await log("check_all_done", summary);
    return json({ ok: true, ...summary });
  } catch (e) {
    const code = (e as { code?: string })?.code === "not_configured" ? "not_configured"
      : (e as Error)?.message === "invalid_feed_header" ? "invalid_response" : "n8n_error";
    await finish({ status: "failed", error_code: code === "not_configured" ? "n8n_error" : code });
    await log("check_all_failed", { run_id: runId, code });
    return json({ ok: false, code }, 502);
  }
}

async function checkOne(runId: string, externalId: string) {
  const t0 = Date.now();
  const ctrl = new AbortController();
  try {
    const body = await openFeed(ctrl.signal);
    const r = await scanFeed(body, new Set([externalId]), { deadlineAt: t0 + 22_000 });
    ctrl.abort();
    const ev = r.found.get(externalId);
    await log("check_one_done", { run_id: runId, found: !!ev, rows: r.rows, ms: Date.now() - t0 });
    return ev
      ? json({ run_id: runId, external_id: externalId, found: true, price: ev.price, old_price: ev.old_price,
               currency: "BRL", source: "admitad_feed", observed_at: new Date().toISOString() })
      : json({ run_id: runId, external_id: externalId, found: false });
  } catch {
    await log("check_one_failed", { run_id: runId });
    return json({ ok: false, code: "n8n_error" }, 502);
  }
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: false }, 405);
  if (!(await authorized(req))) return json({ ok: false, code: "unauthorized" }, 401);
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { return json({ ok: false, code: "bad_request" }, 400); }
  const runId = typeof b.run_id === "string" && UUID.test(b.run_id) ? b.run_id : "";
  if (!runId) return json({ ok: false, code: "bad_request" }, 400);
  if (b.mode === "check_all") return checkAll(runId);
  if ((b.mode === "check_one" || b.mode === "price_check") && typeof b.external_id === "string" && EXT.test(b.external_id)) return checkOne(runId, b.external_id);
  return json({ ok: false, code: "bad_request" }, 400);
});
