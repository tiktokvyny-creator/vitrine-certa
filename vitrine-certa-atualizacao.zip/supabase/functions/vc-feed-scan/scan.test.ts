import { discountOf, scanFeed, splitCsvLine, toEvidence } from "./scan.ts";
function eq(a: unknown, b: unknown, m = "") { const A = JSON.stringify(a), B = JSON.stringify(b); if (A !== B) throw new Error(`esperado ${B}, obtido ${A} ${m}`); }
function streamOf(text: string, chunk = 7): ReadableStream<Uint8Array> {
  const bytes = new TextEncoder().encode(text); let i = 0;
  return new ReadableStream({ pull(c) { if (i >= bytes.length) return c.close(); c.enqueue(bytes.slice(i, i += chunk)); } });
}
const FEED = "\uFEFFid;title;price;oldprice;currencyId;category;picture;url;param\r\n" +
  'A1;"Fone; com ponto e vírgula";89.90;149.90;USD;Eletrônicos;https://i/a.png;https://u/a;shopId|1\r\n' +
  'A2;"Título ""aspas""";1999.00;1999.00;USD;Casa;https://i/b.png;https://u/b;\r\n' +
  "A3;Sem preço;;50;USD;Casa;https://i/c.png;https://u/c;\n" +
  "A4;Ótimo café;39,5;59,9;USD;Casa;https://i/d.png;https://u/d;\n" +
  "ZZ;Outro;10;20;USD;X;https://i/z.png;https://u/z;\n";

Deno.test("splitCsvLine respeita aspas e ';' dentro do título", () => {
  eq(splitCsvLine('A1;"Fone; com ponto";89.90'), ["A1", "Fone; com ponto", "89.90"]);
  eq(splitCsvLine('x;"a ""b""";1'), ["x", 'a "b"', "1"]);
});
Deno.test("toEvidence: valida preço e só aceita preço anterior maior", () => {
  eq(toEvidence(89.9, 149.9, 1), { price: 89.9, old_price: 149.9, row: 1 });
  eq(toEvidence(100, 100, 1), { price: 100, old_price: null, row: 1 });
  eq(toEvidence(0, 10, 1), null); eq(toEvidence(null, 10, 1), null); eq(toEvidence(-1, 10, 1), null);
});
Deno.test("scanFeed encontra os ids pedidos em chunks pequenos, com BOM/CRLF/aspas", async () => {
  const r = await scanFeed(streamOf(FEED), new Set(["A1", "A2", "A3", "A4"]), { deadlineAt: Date.now() + 5000 });
  eq(r.found.get("A1"), { price: 89.9, old_price: 149.9, row: 1 });
  eq(r.found.get("A2"), { price: 1999, old_price: null, row: 2 });
  eq(r.found.has("A3"), false, "sem preço = sem evidência");
  eq(r.found.get("A4"), { price: 39.5, old_price: 59.9, row: 4 });
  eq(r.reason, "endOfFeed"); eq(r.rows, 5);
});
Deno.test("scanFeed para cedo quando todos foram achados", async () => {
  const r = await scanFeed(streamOf(FEED), new Set(["A1"]), { deadlineAt: Date.now() + 5000 });
  eq(r.reason, "allFound"); eq(r.rows, 1);
});
Deno.test("scanFeed respeita o prazo", async () => {
  let t = 0; const r = await scanFeed(streamOf(FEED, 3), new Set(["ZZ"]), { deadlineAt: 5, now: () => t++ });
  eq(r.reason, "deadline");
});
Deno.test("scanFeed recusa header sem id/price", async () => {
  let err = ""; try { await scanFeed(streamOf("a;b\n1;2\n"), new Set(["1"]), { deadlineAt: Date.now() + 1000 }); } catch (e) { err = (e as Error).message; }
  eq(err, "invalid_feed_header");
});
Deno.test("discountOf", () => { eq(discountOf(89.9, 149.9), 40); eq(discountOf(10, null), null); });
