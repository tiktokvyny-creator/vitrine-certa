-- APLICADA em produção em 30/09/2026 (via MCP). Busca de novas ofertas no Supabase (substitui o n8n admitad-sync-brl).
create or replace function public.vc_start_sync(p_requested_by uuid default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_run uuid;
begin
  insert into public.admin_job_runs(kind, status, requested_by)
  values ('sync', 'requested', coalesce(p_requested_by, '00000000-0000-0000-0000-000000000000'::uuid)) returning id into v_run;
  perform net.http_post(url := 'https://ppoelkclmuqojgjrzpkw.supabase.co/functions/v1/vc-sync',
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-vc-job-secret', (select s.value from private.job_secrets s where s.name = 'vc_jobs')),
    body := jsonb_build_object('run_id', v_run), timeout_milliseconds := 170000);
  return v_run;
end $$;
revoke all on function public.vc_start_sync(uuid) from public, anon, authenticated;
grant execute on function public.vc_start_sync(uuid) to service_role;
