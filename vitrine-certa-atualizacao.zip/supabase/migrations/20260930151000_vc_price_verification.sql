-- APLICADA em produção em 30/09/2026 (via MCP). Verificação automática de preços.
alter table public.affiliate_products add column if not exists price_check_misses integer not null default 0;
alter table public.affiliate_products add column if not exists auto_paused_at timestamptz;
alter table public.affiliate_products add column if not exists auto_pause_reason text;
do $$ begin alter table public.affiliate_products add constraint ap_auto_pause_reason check (auto_pause_reason is null or auto_pause_reason in ('price_unconfirmed')); exception when duplicate_object then null; end $$;
do $$ begin alter table public.affiliate_products add constraint ap_price_check_misses check (price_check_misses >= 0); exception when duplicate_object then null; end $$;
create or replace function public.clear_auto_pause_on_reactivate() returns trigger language plpgsql as $$
begin
  if new.active and not old.active then new.auto_paused_at := null; new.auto_pause_reason := null; new.price_check_misses := 0; end if;
  return new;
end $$;
drop trigger if exists zy_clear_auto_pause on public.affiliate_products;
create trigger zy_clear_auto_pause before update of active on public.affiliate_products for each row execute function public.clear_auto_pause_on_reactivate();
create unique index if not exists admin_job_runs_one_active_price_scan on public.admin_job_runs (kind)
  where kind = 'price_check' and product_id is null and status in ('requested', 'running');
create or replace function public.vc_start_price_scan(p_requested_by uuid default null) returns uuid language plpgsql security definer set search_path = '' as $$
declare v_run uuid;
begin
  insert into public.admin_job_runs(kind, status, requested_by, product_id)
  values ('price_check', 'requested', coalesce(p_requested_by, '00000000-0000-0000-0000-000000000000'::uuid), null) returning id into v_run;
  perform net.http_post(url := 'https://ppoelkclmuqojgjrzpkw.supabase.co/functions/v1/vc-feed-scan',
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-vc-job-secret', (select s.value from private.job_secrets s where s.name = 'vc_jobs')),
    body := jsonb_build_object('mode', 'check_all', 'run_id', v_run), timeout_milliseconds := 170000);
  return v_run;
end $$;
revoke all on function public.vc_start_price_scan(uuid) from public, anon, authenticated;
grant execute on function public.vc_start_price_scan(uuid) to service_role;
create or replace function public.vc_auto_pause(p_ids uuid[]) returns integer language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  update public.affiliate_products set active = false, auto_paused_at = now(), auto_pause_reason = 'price_unconfirmed'
   where id = any(p_ids) and active and price_check_misses >= 2;
  get diagnostics n = row_count; return n;
end $$;
revoke all on function public.vc_auto_pause(uuid[]) from public, anon, authenticated;
grant execute on function public.vc_auto_pause(uuid[]) to service_role;
