-- APLICADA em produção em 30/09/2026 (via MCP). Agendamentos.
select cron.schedule('vc-price-scan-4h', '7 */4 * * *', $$
  do $job$ begin perform public.vc_start_price_scan(null);
  exception when unique_violation then raise notice 'verificação de preços já em andamento'; end $job$;
$$);
select cron.schedule('vc-cleanup-logs', '30 3 * * *', $$ delete from private.feed_scan_log where created_at < now() - interval '14 days'; $$);
