-- APLICADA em produção em 30/09/2026 (via MCP). Infraestrutura da automação no Supabase (substitui o n8n).
create extension if not exists pg_net;
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
create table if not exists private.job_secrets (name text primary key, value text not null, created_at timestamptz not null default now());
revoke all on private.job_secrets from public, anon, authenticated;
insert into private.job_secrets(name, value) values ('vc_jobs', encode(extensions.gen_random_bytes(32), 'hex')) on conflict (name) do nothing;
create table if not exists private.feed_scan_log (id bigint generated always as identity primary key, created_at timestamptz not null default now(), stage text not null, data jsonb not null default '{}'::jsonb);
revoke all on private.feed_scan_log from public, anon, authenticated;
create or replace function public.vc_job_secret_ok(p_name text, p_value text) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from private.job_secrets s where s.name = p_name and length(p_value) = 64 and s.value = p_value);
$$;
revoke all on function public.vc_job_secret_ok(text, text) from public, anon, authenticated;
grant execute on function public.vc_job_secret_ok(text, text) to service_role;
create or replace function public.vc_feed_scan_log(p_stage text, p_data jsonb) returns void language sql security definer set search_path = '' as $$
  insert into private.feed_scan_log(stage, data) values (left(p_stage, 40), coalesce(p_data, '{}'::jsonb));
$$;
revoke all on function public.vc_feed_scan_log(text, jsonb) from public, anon, authenticated;
grant execute on function public.vc_feed_scan_log(text, jsonb) to service_role;
