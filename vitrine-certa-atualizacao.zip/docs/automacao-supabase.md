# Automação da Vitrine Certa — tudo no Supabase (sem n8n)

| O quê | Onde | Quando |
|---|---|---|
| Verificar preços de todas as ofertas | Edge Function `vc-feed-scan` (modo `check_all`) | pg_cron `vc-price-scan-4h` (a cada 4 h) e botão "Verificar todos os preços" |
| Verificar preço de uma oferta | `vc-feed-scan` (modo `price_check`) via `vc-admin-jobs` | botão "Verificar preço" nos detalhes |
| Buscar novas ofertas | Edge Function `vc-sync` (regras copiadas do n8n `admitad-sync-brl`) | botão "Pesquisar novas ofertas" |
| Limpeza de registros técnicos | pg_cron `vc-cleanup-logs` | diariamente, 03:30 UTC |

Regras de preço: o valor exibido é o do feed da Admitad (BRL efetivo). Oferta ativa não confirmada
em 2 verificações seguidas é pausada automaticamente (`auto_paused_at`); reativar limpa a marcação.

Segredos usados (Edge Functions → Secrets): `ADMITAD_FEED_URL`, `INTERNAL_TRIGGER_SECRET` (já existentes)
e `OPENAI_API_KEY` (opcional; sem ela, produtos sem categoria por palavras-chave ficam em "Outros").
O segredo interno entre banco e funções fica em `private.job_secrets` (fora da API).

O workflow original do n8n está em `docs/n8n-backup/admitad-sync-brl.json` (sem credenciais).
